package packt.mastering.java9.process;

public class ChildToBeTerminated {
    public static void main(String[] args) throws InterruptedException {
        Thread.sleep(10_000);
    }
}
