package packt.mastering.java9.stackwalker;

public class StackDumpCaller extends AbstractStackDumpCaller{
    @Override
    public void calme() {
        dumper();
    }
}
