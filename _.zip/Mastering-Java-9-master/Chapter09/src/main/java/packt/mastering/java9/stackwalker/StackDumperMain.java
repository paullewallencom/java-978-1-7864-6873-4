package packt.mastering.java9.stackwalker;

public class StackDumperMain {
    public static void main(String[] args){
        new StackDumpCaller().calme();
    }
}
